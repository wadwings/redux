let global = {
    fullscreen: false
}

module.exports = exports =  global;